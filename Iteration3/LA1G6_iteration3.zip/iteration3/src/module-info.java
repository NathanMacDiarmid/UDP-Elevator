/**
 * 
 */
/**
 * @author M-Dawg
 *
 */
module iteration3 {
	requires org.junit.jupiter.api;
}