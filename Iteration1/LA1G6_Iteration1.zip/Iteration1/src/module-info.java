/**
 * 
 */
/**
 * @author M-Dawg
 *
 */
module Iteration1 {
	requires org.junit.jupiter.api;
	requires junit;
}