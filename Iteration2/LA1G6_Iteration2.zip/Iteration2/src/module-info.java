/**
 * 
 */
/**
 * @author M-Dawg
 *
 */
module Iteration2 {
	requires junit;
	requires org.junit.jupiter.api;
}